"""M2 exactness/confluence and rule-preserving owner-fill diagnostics.

These are lattice, capacity and concave-moment protocols. No intrinsic graph
Laplacian or sandpile group is supplied by the word or fill. Every parallel
entry is intended for pipeline/pool.py, after the coordinator preregisters it.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import replace
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import hashlib
import json
import math
import random
import statistics
import time

import fill

_SAMPLERS=[]
_OPTIMA={}
_COSTS=None
_REPAIRS=[]
_REPAIR_REFERENCES={}


def prepare_s2(paths,endpoint="0.001717794984118634663827"):
    """Parent-load exact graph objects; solving is a separate pool task."""
    import nulls
    import wordio
    global _SAMPLERS,_COSTS
    _SAMPLERS=[nulls.FrameSampler(wordio.load(path)) for path in paths]
    F,_=wordio.toolkit();_COSTS=F.Costs(endpoint)
    _OPTIMA.clear()
    _delta_interval.cache_clear()
    return [dict(index=i,word=s.word.attribution,variables=len(s.variables)) for i,s in enumerate(_SAMPLERS)]


def _json_metadata(value):
    if isinstance(value,Fraction):
        return str(value)
    if isinstance(value,dict):
        if any(not isinstance(k,(str,int,float,bool,type(None))) for k in value):
            return {"entries":[{"key":_json_metadata(k),"value":_json_metadata(v)} for k,v in value.items()]}
        return {k:_json_metadata(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):
        return [_json_metadata(x) for x in value]
    return value


def optimum_task(arg):
    """One reference solve with true-cost interval, outside all order loops."""
    import nulls
    import wordio
    sampler=_SAMPLERS[arg["index"]]
    endpoint=arg.get("endpoint","0.001717794984118634663827")
    F,_=wordio.toolkit()
    start=time.monotonic()
    try:
        with nulls.solver_timeout(min(600,arg.get("timeout",600))):
            costs=F.Costs(endpoint)
            result=F.optimal_frames(sampler.graph.w,costs,graph=sampler.graph,
                                    check_literal=True,interval=True)
    except TimeoutError as exc:
        return dict(status="TIMEOUT",certified=False,endpoint=endpoint,reason=str(exc),
                    seconds=time.monotonic()-start)
    profile=Counter(result["profile"]);profile.update(sampler.word.centre_paid)
    literal=Counter(result["literal_profile"]);literal.update(sampler.word.centre_paid)
    interval=result.get("interval")
    valid_interval=bool(interval is not None and interval["lower"]<=interval["upper"])
    return dict(status="PASS" if result["certified"] and valid_interval else "EXPLORATORY",
                certified=bool(result["certified"]),integer_surrogate_certified=bool(result["certified"]),
                certification="Exact integer-surrogate optimum; rational interval bounds the true toolkit cost minimum. It does not establish uniqueness of a true-moment optimum profile.",
                endpoint=endpoint,cost=str(result["cost"]),literal_cost=str(result["literal_cost"]),
                profile=dict(profile),literal_profile=dict(literal),
                true_moment_interval=_json_metadata(interval),true_moment_interval_valid=valid_interval,
                surrogate_not_true_minimal=bool(interval and interval.get("surrogate_not_minimal")),
                true_cost_scope="Pinned toolkit T_r includes its per-child fallback overhead; this is not the global kappa-root equation. Interval excludes the unchanged centre descents.",
                centre_paid=dict(sampler.word.centre_paid),parts=_json_metadata(result["parts"]),
                seconds=time.monotonic()-start)


@lru_cache(maxsize=4096)
def _delta_interval(delta_key):
    lower=sum(n*(_COSTS.exact[r] if n>0 else _COSTS.upper[r]) for r,n in delta_key)
    upper=sum(n*(_COSTS.upper[r] if n>0 else _COSTS.exact[r]) for r,n in delta_key)
    return lower,upper


def install_optimum(index,metadata):
    """Install the already checked one-per-word reference in the parent."""
    _OPTIMA[index]=metadata


def _local_delta(sampler,assignment,k,new):
    import wordio
    g=sampler.graph
    current=lambda j:assignment.get(j,tuple(g.nodes[j][1]))
    delta=Counter()
    for left,right,reg in sampler.edges[k]:
        oldl,oldr=current(left),current(right)
        newl=new if left==k else oldl
        newr=new if right==k else oldr
        if not wordio.contained(newl,newr):return None
        oldd,newd=len(oldr)-len(oldl),len(newr)-len(newl)
        if oldd:delta[oldd]-=1
        if newd:delta[newd]+=1
    return {r:n for r,n in delta.items() if n}


def _order_seed(experiment, seed, identity, order):
    """Order streams are independent of batch boundaries and worker scheduling."""
    data=json.dumps([experiment,int(seed),identity,int(order)],sort_keys=True,separators=(",",":"))
    return int.from_bytes(hashlib.sha256(data.encode()).digest()[:16],"big")


def _word_identity(sampler):
    attribution=sampler.word.attribution
    return {k:attribution[k] for k in ("pin_key","git_blob","blob","sha256") if k in attribution} or attribution


def _reference_comparison(sampler,optimum):
    reference={int(r):n for r,n in optimum["profile"].items()}
    lower=sum(n*_COSTS.exact[r] for r,n in reference.items())
    upper=sum(n*_COSTS.upper[r] for r,n in reference.items())
    comparison_upper=upper
    interval=optimum.get("true_moment_interval")
    if interval and interval.get("fine_upper") is not None:
        centre_upper=sum(n*_COSTS.upper[r] for r,n in sampler.word.centre_paid.items())
        comparison_upper=min(upper,Fraction(interval["fine_upper"])+centre_upper)
    return reference,lower,upper,comparison_upper


def _one_confluence_order(index,seed,order):
    import wordio
    sampler=_SAMPLERS[index];g=sampler.graph
    rng_seed=_order_seed("S-2",seed,_word_identity(sampler),order)
    rng=random.Random(rng_seed)
    assignment={k:tuple(g.upper[k]) for k in sampler.variables}
    initial_potential=sum(len(x) for x in assignment.values())
    minimum_potential=sum(len(g.lower[k]) for k in sampler.variables)
    moves=0;sweep=0;unresolved=0;examples=[]
    while True:
        sweep+=1;changed=False;sweep_unresolved=0
        variables=list(sampler.variables);rng.shuffle(variables)
        for k in variables:
            old=assignment[k];candidates=[]
            for new in sampler.domains[k]:
                if len(new)>=len(old) or not wordio.contained(new,old):continue
                delta=_local_delta(sampler,assignment,k,new)
                if not delta:continue
                lower,upper=_delta_interval(tuple(sorted(delta.items())))
                if upper<0:
                    candidates.append(new)
                elif lower<0:
                    unresolved+=1;sweep_unresolved+=1
                    if len(examples)<20:
                        examples.append(dict(order=order,sweep=sweep,gate=_json_metadata(k),
                            delta=delta,lower=str(lower),upper=str(upper)))
            if candidates:
                assignment[k]=rng.choice(candidates);moves+=1;changed=True
        if not changed:
            break
    final_potential=sum(len(x) for x in assignment.values())
    if not minimum_potential<=final_potential<=initial_potential or moves>initial_potential-final_potential:
        raise AssertionError("Strict dimension potential failed")
    profile=Counter(g.profile(assignment));profile.update(sampler.word.centre_paid)
    profile=dict(sorted(profile.items()))
    state=[[_json_metadata(k),list(assignment[k])] for k in sampler.variables]
    state_sha=hashlib.sha256(json.dumps(state,separators=(",",":")).encode()).hexdigest()
    return dict(order=order,order_seed=str(rng_seed),profile=profile,
        assignment_sha256=state_sha,accepted_lowerings=moves,sweeps=sweep,
        unresolved_legal_deltas=unresolved,unresolved_terminal_deltas=sweep_unresolved,
        unresolved_examples=examples,dimension_potential_initial=initial_potential,
        dimension_potential_final=final_potential,dimension_potential_lower_bound=minimum_potential,
        terminal_maximality_verified=sweep_unresolved==0)


def confluence_batch_task(arg):
    """Small pool checkpoint; no solver call occurs inside an order loop."""
    index,seed=arg["index"],arg["seed"]
    sampler=_SAMPLERS[index];optimum=_OPTIMA.get(index)
    first=arg.get("start_order",0);count=arg.get("order_count",1)
    if not 0<=first<100 or not 1<=count<=100-first:
        raise ValueError("S-2 batch must be contained in orders 0..99")
    if not optimum or not optimum.get("certified"):
        return dict(status="EXPLORATORY",index=index,seed=seed,word=sampler.word.attribution,
            start_order=first,order_count=count,orders=[],decision="Certified reference missing.")
    if Fraction(optimum["endpoint"])!=_COSTS.b:
        raise ValueError("Reference and dynamics endpoints differ")
    orders=[_one_confluence_order(index,seed,order) for order in range(first,first+count)]
    return dict(status="PASS",index=index,seed=seed,word=sampler.word.attribution,
        start_order=first,order_count=count,orders=orders,
        decision="Batch computed; scientific decision requires all 100 prescribed orders.")


def _unwrap_batches(outputs):
    values=[];failures=[]
    for i,out in enumerate(outputs):
        if out.get("status")=="OK":
            values.append(out["result"])
        elif "result" in out or out.get("status") in ("ERROR","TIMEOUT"):
            failures.append(dict(batch=i,status=out.get("status"),error=out.get("error")))
        else:
            values.append(out)
    return values,failures


def summarize_confluence(outputs,index,seed):
    """Preserve the >=95/100 bar; partial/missing batches cannot decide it."""
    sampler=_SAMPLERS[index];optimum=_OPTIMA.get(index)
    values,failures=_unwrap_batches(outputs)
    orders=[];identities_valid=True
    for value in values:
        identities_valid &= value.get("index")==index and value.get("seed")==seed
        orders.extend(value.get("orders",[]))
    order_ids=[o["order"] for o in orders]
    complete=identities_valid and sorted(order_ids)==list(range(100))
    technical=next((x["status"] for x in failures if x["status"]=="ERROR"),None)
    technical=technical or ("TIMEOUT" if failures else None)
    if not complete or not optimum or not optimum.get("certified"):
        return dict(status=technical or "EXPLORATORY",n_permutations=len(orders),
            statistics=dict(index=index,seed=seed,word=sampler.word.attribution,
                prescribed_orders=100,completed_orders=len(orders),order_ids=order_ids,
                identities_valid=identities_valid,failures=failures,certified_reference=optimum),
            decision="All 100 unique prescribed orders and a certified reference are required.")
    orders.sort(key=lambda x:x["order"])
    reference,ref_lower,ref_upper,comparison_upper=_reference_comparison(sampler,optimum)
    terminal_counts=Counter(tuple(sorted((int(r),n) for r,n in o["profile"].items())) for o in orders)
    hits=sum({int(r):n for r,n in o["profile"].items()}==reference for o in orders)
    unresolved=sum(o["unresolved_legal_deltas"] for o in orders)
    terminal_unresolved=sum(o["unresolved_terminal_deltas"] for o in orders)
    terminals=[];proved_worse=0
    for profile_key,count in sorted(terminal_counts.items()):
        p=dict(profile_key)
        lower=sum(n*_COSTS.exact[r] for r,n in p.items())
        upper=sum(n*_COSTS.upper[r] for r,n in p.items())
        worse=lower>comparison_upper
        if worse:proved_worse+=count
        terminals.append(dict(profile=p,count=count,cost_lower=str(lower),cost_upper=str(upper),
            strictly_worse_than_reference_certified=worse))
    interval_valid=optimum.get("true_moment_interval_valid",False)
    if hits>=95 and unresolved==0 and interval_valid and not optimum.get("surrogate_not_true_minimal",False):
        status="PASS"
        decision=f"{hits}/100 profiles equal the certified integer-surrogate reference; all local true-cost signs and maximality checks resolved."
    elif proved_worse>5 and terminal_unresolved==0 and interval_valid:
        status="NULL"
        decision=f"{proved_worse}/100 maximal terminal profiles are rigorously worse than a feasible reference, failing the >=95/100 bar."
    else:
        status="EXPLORATORY"
        decision="True-cost sign, interval, or terminal comparison uncertainty prevents a definitive confluence verdict."
    value=dict(word=sampler.word.attribution,index=index,seed=seed,orders=100,
        order_stream="SHA256(experiment, seed, immutable word identifiers, order index), independent of batching",
        certified_reference=optimum,hits=hits,hit_rate=hits/100,
        distinct_terminal_profiles=len(terminal_counts),terminals=terminals,
        distinct_terminal_assignments=len({o["assignment_sha256"] for o in orders}),
        order_results=orders,strict_true_cost_decreases_verified=sum(o["accepted_lowerings"] for o in orders),
        unresolved_legal_deltas=unresolved,unresolved_terminal_deltas=terminal_unresolved,
        proved_worse_terminals=proved_worse,reference_true_cost_lower=str(ref_lower),
        reference_true_cost_upper=str(ref_upper),best_feasible_comparison_cost_upper=str(comparison_upper),
        terminal_maximality_verified=terminal_unresolved==0,
        terminal_maximality="Final full sweep tests every legal proper-subspace single-gate lowering using rational cost intervals.",
        potential_proof="Sum of mutable frame dimensions is a nonnegative integer and strictly decreases at every accepted lowering; this proves termination only.",
        exact_true_optimum_profile_proved=False,
        scope="Profile agreement to a certified integer-surrogate reference at one endpoint. A true-minimum interval does not prove a unique exact-moment optimum profile; no state-confluence or abelianity theorem.")
    return dict(status=status,statistics=value,n_permutations=100,decision=decision)


def confluence_task(arg):
    """Compatibility wrapper; the coordinator should checkpoint small batches."""
    if arg.get("orders",100)!=100:
        raise ValueError("S-2 registration requires exactly 100 orders per seed")
    return summarize_confluence([confluence_batch_task(dict(arg,start_order=0,order_count=100))],
                                 arg["index"],arg["seed"])


def window_dag_audit(model):
    """All eligibility arcs go call(t,0) -> window(stop,1), a sink DAG."""
    count=0;zero=0
    for cap,start,stop in model.win.values():
        if stop<=start:zero+=1
        for t in range(max(0,start+1),min(model.calls-1,stop)+1):
            if not (t,0)<(stop,1):raise ValueError("non-DAG eligibility arc")
            count+=1
    return dict(vertices=model.calls+len(model.win),arcs=count,
                sink_windows=len(model.win),empty_eligibility_windows=zero,
                acyclic=True,topological_order="lexicographic (call-time,0), (window-stop,1)",
                intrinsic_laplacian=False,group_identity_burning="DROPPED: no intrinsic Laplacian or toppling rule")


def _walk_state(model):
    rem={(o,c,p):cap for (o,c),(cap,_,_) in model.win.items() for p in range(model.ports)}
    families=[set() for _ in range(model.calls)]
    rows=[tuple(r[:5]) for r in model.rows]
    for t,h,o,c,p in rows:
        rem[o,c,p]-=model.widths[t][h];families[t].add(model.family_id(o,c,p))
    eligible=[[] for _ in range(model.calls)]
    for (o,c),(cap,start,stop) in model.win.items():
        for t in range(max(0,start+1),min(model.calls-1,stop)+1):eligible[t].append((o,c))
    return rows,rem,families,eligible


def _proposal(model,rows,rem,families,eligible,rng,mutate):
    i=rng.randrange(len(rows));t,h,o,c,p=rows[i];old=o,c,p;width=model.widths[t][h]
    oldfam=model.family_id(o,c,p);rem[old]+=width;families[t].remove(oldfam)
    dest=old
    for _ in range(60):
        o2,c2=rng.choice(eligible[t]);p2=rng.randrange(model.ports);candidate=o2,c2,p2
        if rem[candidate]>=width and model.family_id(o2,c2,p2) not in families[t]:
            dest=candidate;break
    changed=dest!=old
    if changed:
        # Remainder changes: x->x+w at source, y->y-w at destination.
        before=(rem[old]-width,rem[dest]);after=(rem[old],rem[dest]-width)
    else:
        before=after=(rem[old]-width,)
    if mutate:
        rem[dest]-=width;families[t].add(model.family_id(*dest));rows[i]=(t,h)+dest
    else:
        rem[old]-=width;families[t].add(oldfam)
    return before,after,changed


def walk_slope(model,seed,moves=300000,pilot=10000,initial_checkpoint=1000):
    """Independent literal-state pilot predicts initial per-attempt root decay.

    Every move preserves exact family/time/capacity constraints. Prefix offsets
    are rebuilt deterministically for the final independent literal audit.
    The chain is local and starts at the shipped fill; no uniformity claim.
    """
    if pilot<=0 or initial_checkpoint<=0 or moves<initial_checkpoint:
        raise ValueError("Positive pilot/checkpoint and moves>=checkpoint are required")
    baseline=fill.audit(model)
    local=model.overlay_local_profiles or model.local_profiles
    idle0=baseline["idle"]
    profile0=fill._profile(local,idle0);k0=fill.kappa_float(profile0)
    derivative=math.fsum(c*(r/73)**(1-k0)*math.log(73/r) for r,c in profile0.items())
    weights={r:(r/73)**(1-k0) if r else 0.0 for r in range(1+max(c for c,_,_ in model.win.values()))}
    rows,rem,families,eligible=_walk_state(model)
    pilot_rng=random.Random(seed^0x534C4F50);pilot_deltas=[];pilot_changes=0
    for _ in range(pilot):
        before,after,changed=_proposal(model,rows,rem,families,eligible,pilot_rng,False)
        delta=math.fsum(weights[r] for r in after)-math.fsum(weights[r] for r in before)
        pilot_deltas.append(-delta/derivative);pilot_changes+=changed
    predicted=statistics.fmean(pilot_deltas)
    rng=random.Random(seed)
    checkpoints=sorted(set([initial_checkpoint,3000,10000,30000,100000,moves]))
    checkpoints=[x for x in checkpoints if x<=moves]
    log=[];accepted=0;cumulative_delta=0.0
    for step in range(1,moves+1):
        before,after,changed=_proposal(model,rows,rem,families,eligible,rng,True)
        accepted+=changed
        cumulative_delta+=math.fsum(weights[r] for r in after)-math.fsum(weights[r] for r in before)
        if step in checkpoints:
            idle=Counter(r for r in rem.values() if r)
            profile=fill._profile(local,idle);k=fill.kappa_float(profile)
            clump=sum(rem[b] in (0,model.win[b[:2]][0]) for b in rem)/len(rem)
            log.append(dict(attempts=step,changed_moves=accepted,kappa=k,kappa_delta=k-k0,
                            linearized_path_delta=-cumulative_delta/derivative,
                            clumping=clump,idle=dict(sorted(idle.items()))))
    measured=log[0]["kappa_delta"]/initial_checkpoint
    relerr=abs(measured-predicted)/abs(predicted) if predicted else None
    final_rows=fill.compact_rows(model,rows)
    final=fill.audit(model,final_rows,require_profile=False)
    status="EXPLORATORY" if relerr is None else "PASS" if relerr<=.1 and baseline["clumping"]>=.75 else "NULL"
    return dict(status=status,statistics=dict(fill=model.name,seed=seed,pilot_attempts=pilot,
                 pilot_changed_moves=pilot_changes,pilot_slope_sd=statistics.pstdev(pilot_deltas),
                 predicted_initial_slope=predicted,measured_initial_slope=measured,
                 initial_checkpoint_attempts=initial_checkpoint,relative_error=relerr,
                 original_clumping=baseline["clumping"],clumping_bar=.75,trace=log,
                 final_literal_rules_verified=final["all_literal_rules_verified"],
                 final_profile=fill._profile(local,final["idle"]),window_dag=window_dag_audit(model),
                 attribution=model.attributions,sources=model.sources,
                 profile_basis="held-word overlay" if model.overlay_local_profiles else "literal provider metadata",
                 scope="Independent one-state pilot vs finite early local-walk slope; not a uniform feasible-fill null."),
                n_permutations=0,
                decision=f"Initial slope relative error {relerr} (bar 0.1; None means a zero pilot prediction); initial clumping {baseline['clumping']:.6g} (bar 0.75).")


def fill_task(arg):
    model=fill._MODELS[arg.get("index",0)]
    if arg["experiment"]=="S-4":
        return walk_slope(model,arg["seed"],arg.get("moves",300000),arg.get("pilot",10000),arg.get("initial_checkpoint",1000))
    if arg["experiment"]=="M2-AUDIT":
        return dict(status="PASS",statistics=dict(literal=fill.audit(model),dag=window_dag_audit(model)),
                    decision="Literal conservation and sink DAG exact; intrinsic Laplacian absent.",n_permutations=0)
    raise ValueError(arg["experiment"])
