"""Independent finite admission for continuation candidates.

The coordinator must preregister before calling any audit function, and must
launch workers through styles-r11/pipeline/pool.py.  This module has no pool,
solver, subprocess, automatic experiment, or fetched-code import.

``prepare(record)`` accepts the already parent-loaded heldout_data.RECORDS['2853'].
``audit_fill_candidate(spec)`` accepts a pinned inert FILL.json.gz artifact.
``local_admission(raw, attribution)`` is also available to word constructors.

Finite complex-root separation, native supplier admission, strict global
admission, outer arithmetic, and the inherited theorem are distinct tiers.
The first does not silently stand in for the latter four.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from decimal import Decimal, localcontext
from fractions import Fraction as Q
from functools import lru_cache
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import random
import sys
import time

HERE = Path(__file__).resolve().parent
PIPELINE = HERE.parent
RR = PIPELINE.parent
ROOT = RR.parents[1]
HEAD = 'd01045dfb67428679618027dff552f1d032fa999'
DATA_MANIFEST_SHA = '9f515fdcead2753a0fdc176417e26468e6e77eb537fdcd20f53496e00a599567'
PINS_SHA = '4d62f7caf94a102ebb83feb3beca6ebeb1ab9637901ff51cc84e5beeb15d2a65'
WORDS = {'gauge44': 'new/borrow/words/BORROW-WORD-43base.json.gz',
         'extra': 'new/borrow/words/BORROW-WORD-43extra.json.gz'}
TRUSTED = {
    'wordio': ('research/styles-r11/pipeline/wordio.py',
               'a9c254acdc04c3302ed0a31d9e0da39a8e3348aa20d189798e86539464fd81d4'),
    'fill': ('research/styles-r11/pipeline/fill.py',
             '9ca05b47016ddbbb4a6713c981932d63a6eaecdd27f3604fcfb66877f239fc4a'),
    'growth': ('research/styles-r11/pipeline/growth.py',
               '4f29eba652ea1c7ca889f784c612a6ab11d8aefe96637d18bd32391532b8f167'),
    'auditor': ('research/t74-joint-twelve-retired7/vendor/audit_local_pr2679.py',
                'a38940094f7d19cd6376aafdd4734fa68eabc9aff4c98c3c4a3e9540328b1c90'),
    'owners': ('research/t74-joint-twelve-retired7/independent_owners.py',
               '219e16a7f35c5c9e9640760c28ad49a17b546c9f32bdf57dd76c30b5dd096aa6'),
    'moment': ('research/t74-joint-twelve-retired7/exact_moment.py',
               'f170292f7983773d4f142afdac4677c1615fb7b781dbabf395200aea886dcade'),
}
_MODULES = {}
_BASE = None


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def semantic_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def read_data(path):
    """Only inert JSON; this function never treats a path as an executable."""
    path = Path(path)
    need(path.name.endswith(('.json', '.json.gz')), 'only JSON/gzip JSON data accepted')
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.name.endswith('.gz') else raw)


def _module(name):
    relative, digest = TRUSTED[name]
    path = (ROOT / relative).resolve()
    need(sha(path) == digest, 'trusted source drift: ' + relative)
    if name not in _MODULES:
        need(not sys.flags.optimize, 'admission requires enabled assertions')
        sys.dont_write_bytecode = True
        spec = importlib.util.spec_from_file_location('styles_continuation_admission_' + name, path)
        module = importlib.util.module_from_spec(spec)
        # dataclasses resolves annotations through the defining module.
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        _MODULES[name] = module
    return _MODULES[name]


def source_manifest():
    for relative, digest in TRUSTED.values():
        need(sha(ROOT / relative) == digest, 'trusted source drift: ' + relative)
    return {relative: digest for relative, digest in TRUSTED.values()}


def profile(value):
    need(isinstance(value, dict), 'profile object required')
    result = {}
    for rank, count in value.items():
        r = int(rank)
        need(str(r) == str(rank) and 0 < r < 73, 'canonical positive rank below dimension')
        need(type(count) is int and count >= 0, 'nonnegative integer multiplicity')
        if count:
            result[r] = count
    need(result, 'empty paid profile')
    return dict(sorted(result.items()))


def _mass(value):
    return sum(rank * count for rank, count in value.items())


def prepare(record):
    """Bind an existing parent-loaded #2853 record, without running an audit.

    The caller owns heldout_data.prepare and its memory accounting.  No large
    fill/template object is loaded again here.  Hash verification reads bytes,
    but does not create another parsed fill/template.
    """
    global _BASE
    source_manifest()
    need(_BASE is None, 'parent preparation is once-only')
    need(record.get('pr') == '2853' and record.get('prepare_error') is None,
         'prepared #2853 record required')
    directory = RR / 'data/heldout/2853'
    need(sha(directory / 'DATA-MANIFEST.json') == DATA_MANIFEST_SHA, 'held source manifest pin')
    need(sha(RR / 'data/words/PINS.json') == PINS_SHA, 'inherited attribution pin')
    manifest = read_data(directory / 'DATA-MANIFEST.json')
    need(record['manifest'] == manifest and manifest['commit'] == HEAD, 'parent record manifest binding')
    for relative, pin in manifest['files'].items():
        path = (directory / 'package' / relative).resolve()
        need(path.is_relative_to((directory / 'package').resolve()), 'inert source path confinement')
        need(sha(path) == pin['sha256'], 'source file digest: ' + relative)
    data, model = record['data'], record['model']
    need((record['dimension'], record['wires'], model.calls) == (73, 66304, 666), 'fixed T74 geometry')
    need([list(x) for x in model.rows] == data['new/borrow-fill/FILL.json.gz']['rows'], 'model literal rows')
    need([list(x) for x in model.order] == data['new/borrow-fill/ORDER.json'], 'model literal order')
    need(set(record['words']) == set(WORDS), 'both pinned providers required')
    for provider, relative in WORDS.items():
        need(record['words'][provider].raw == data[relative], 'canonical word/payload equality')
    _BASE = record
    # All imports below are source pinned, stdlib-only at import time.
    for name in TRUSTED:
        _module(name)
    return dict(pr=2853, commit=HEAD, parent_objects_loaded_once=True,
                source_manifest_sha256=DATA_MANIFEST_SHA, trusted_sources=source_manifest(),
                calls=model.calls, roles=len(model.rows),
                word_pins={pid: deepcopy(manifest['files'][rel]) for pid, rel in WORDS.items()})


def _base():
    need(_BASE is not None, 'prepare(record) must run once in the parent before pool launch')
    return _BASE


def provenance():
    b = _base()
    pins = read_data(RR / 'data/words/PINS.json')['files']
    return dict(source_attribution=[dict(path=key, **value) for key, value in pins.items()] +
                [deepcopy(b['manifest']['files'][rel]) for rel in WORDS.values()],
                inherited_pins_sha256=PINS_SHA, held_manifest_sha256=DATA_MANIFEST_SHA,
                trusted_sources=source_manifest())


class _MemoryPath:
    def __init__(self, name, payload=b''):
        self.name, self.payload = name, payload

    def read_bytes(self):
        return self.payload

    def write_text(self, text):
        self.payload = text.encode()


def local_admission(raw, attribution):
    """Exact frame/paid bill and free-operator map; no native phase claim."""
    started = time.process_time()
    W, A = _module('wordio'), _module('auditor')
    need(raw.get('kind') == 'BORROW-WORD', 'BORROW-WORD candidate required')
    canonical = W.WordData(raw, attribution)
    payload = json.dumps(raw, separators=(',', ':')).encode()
    inp = _MemoryPath('candidate.json.gz', gzip.compress(payload, mtime=0))
    out, log = _MemoryPath('audit.json'), io.StringIO()
    with contextlib.redirect_stdout(log):
        report = A.run_borrow(inp, out, None, None, raw, payload, time.monotonic())
    need(report['status'] == 'PASS_INDEPENDENT_EXACT_BORROWING_WORD', 'free-algebra audit status')
    need(report['orientations'] == {'forward': 'PASS', 'dual': 'PASS'}, 'both orientations')
    need(report['checked_columns'] == len(canonical.live), 'all independent live columns')
    need(profile(report['local_profile']) == canonical.paid, 'independent local profile parity')
    widths = [len(canonical.end[r]) - len(canonical.start[r]) for r in canonical.helpers]
    need(all(type(w) is int and w > 0 for w in widths), 'positive physical helper widths')
    return dict(status='PASS', tier='finite_local_free_operator_algebra', audit=report,
                paid_profile=canonical.paid, ordered_helpers=canonical.helpers, widths=widths,
                word_semantic_sha256=semantic_sha(raw), source_attribution=deepcopy(attribution),
                cpu_seconds=time.process_time() - started,
                native_clifford_phase_and_gaussian_checked=False,
                parent_global_supplier_and_outer_checked=False)


def _normalized_owner_plan():
    """Exact adapter between two stored deficit conventions; no geometry change."""
    b = _base()
    original = b['data']['new/PLAN.json']
    M, W, deficit = (original[key] for key in ('M', 'live', 'deficit'))
    need((M, W) == (73, 66304) and type(deficit) is int, 'literal plan geometry')
    total = M * W + deficit
    need(total % 2 == 0, 'integer two-sided deficit')
    adapted = dict(original, deficit=total // 2)
    mass = M * W - deficit
    need(mass == 2 * (M * W - adapted['deficit']) == 4816512,
         'single- and two-sided coverage identities')
    return adapted, dict(original_deficit=deficit, independent_checker_deficit=adapted['deficit'],
                         formula='D_two_sided=(73*W+D_single_sided)/2', exact_rank_mass=mass,
                         changed_input_field_only='internal deficit convention; not a candidate edit')


def _provider_binding():
    b, W = _base(), _module('wordio')
    providers = {}
    word_hashes = {}
    for pid, relative in WORDS.items():
        raw = b['data'][relative]
        canonical = W.WordData(raw, b['manifest']['files'][relative])
        widths = [len(canonical.end[h]) - len(canonical.start[h]) for h in canonical.helpers]
        declared = b['data']['new/BORROW-PROVIDERS.json'][pid]
        need(widths == declared['widths'] and canonical.paid == profile(declared['actual_paid_profile']),
             'canonical pinned provider inventory and profile')
        providers[pid] = dict(widths=widths, actual_paid_profile=canonical.paid)
        word_hashes[pid] = dict(compressed_sha256=b['manifest']['files'][relative]['sha256'],
                                semantic_sha256=semantic_sha(raw))
    for t, call in enumerate(b['model'].order):
        provider = providers[b['dispatch'][call]]
        need(tuple(provider['widths']) == tuple(b['model'].widths[t]), 'actual dispatched widths')
        need(provider['actual_paid_profile'] == profile(b['model'].local_profiles[t]), 'actual dispatched local bill')
    return providers, word_hashes


def literal_admission(candidate_fill):
    """Two independent literal owner checks on a fixed-word/order/template fill."""
    b, F, I = _base(), _module('fill'), _module('owners')
    original = b['data']['new/borrow-fill/FILL.json.gz']
    need(candidate_fill['columns'] == original['columns'] == F.COLUMNS, 'literal fill columns')
    need(candidate_fill['dispatch_overrides'] == original['dispatch_overrides'], 'fixed dispatch overrides')
    providers, word_hashes = _provider_binding()
    # require_profile=False derives the candidate's complete profile instead of
    # comparing against the original expected profile. All actual rules remain.
    literal = F.audit(b['model'], rows=candidate_fill['rows'], require_profile=False)
    paid = profile(literal['profile'])
    plan, convention = _normalized_owner_plan()
    initial = {(s, r): pid for s, r, pid in b['data']['new/borrow-fill/DISPATCH.json']}
    independent = I.check(plan, b['data']['GLOBAL-TEMPLATE.json.gz'], b['model'].order,
                          candidate_fill, providers, initial, paid)
    need(independent['profile'] == paid and independent['idle'] == literal['idle'], 'independent profile/idle parity')
    need(independent['window_sha256'] == literal['window_sha256'], 'independent chronology parity')
    need(_mass(paid) == literal['rank_mass'] == 4816512, 'exact unchanged coverage mass')
    aggregate = Counter()
    for call in b['model'].order:
        aggregate.update(providers[b['dispatch'][call]]['actual_paid_profile'])
    need(Counter(paid) == aggregate + Counter(literal['idle']), 'complete local plus idle identity')
    return dict(status='PASS', profile=paid, idle=literal['idle'], aggregate_local_profile=dict(aggregate),
                rank_mass=4816512, independent_owner_audit=independent,
                literal_fill_audit=literal, deficit_convention=convention,
                fixed_local_words=word_hashes,
                frozen_inputs=dict(order=semantic_sha(b['model'].order),
                    dispatch=semantic_sha(sorted((s, r, pid) for (s, r), pid in b['dispatch'].items())),
                    template=b['manifest']['files']['GLOBAL-TEMPLATE.json.gz']['sha256'],
                    native_invoice_declarations=semantic_sha(b['data']['new/SPEC.json']['providers'])))


@lru_cache(maxsize=8192)
def _cost(rank, endpoint):
    """Outward round exact retained atanh/Taylor bounds to a 10^-40 grid."""
    lower, upper = _module('moment').moment_bounds({rank: 1}, Q(endpoint))
    grid = 10 ** 40
    low = Q((lower.numerator * grid) // lower.denominator, grid)
    high = Q(-((-upper.numerator * grid) // upper.denominator), grid)
    need(low <= lower <= upper <= high, 'outward rational coefficient enclosure')
    return low, high


def moment_bounds(value, endpoint):
    value = profile(value)
    k = Q(endpoint)
    need(0 <= k < Q(1, 500), 'registered small positive exponent range')
    lower = sum(count * _cost(rank, str(k))[0] for rank, count in value.items())
    upper = sum(count * _cost(rank, str(k))[1] for rank, count in value.items())
    return lower, upper


def root_separation(candidate_profile, baseline_profile, separator=None):
    """Prove old root < q < new root with a common exact rational q.

    One fixed midpoint proposal is used when q is omitted. Decimal roots are
    proposals only; the final decision uses outward rational moments exclusively.
    """
    candidate_profile, baseline_profile = profile(candidate_profile), profile(baseline_profile)
    need(_mass(candidate_profile) == _mass(baseline_profile) == 4816512, 'same complete coverage mass')
    numerical = None
    if separator is None:
        G = _module('growth')
        G._root_cached.cache_clear()
        old, new = G.root(baseline_profile), G.root(candidate_profile)
        with localcontext() as context:
            context.prec = 90
            separator = str((old + new) / 2)
        numerical = dict(baseline=str(old), candidate=str(new), protocol='90 digits, 280 bisections; proposal only')
    q = Q(separator)
    old_lower, old_upper = moment_bounds(baseline_profile, q)
    new_lower, new_upper = moment_bounds(candidate_profile, q)
    passed = old_lower > 66304 > new_upper
    return dict(status='PASS' if passed else 'NOT_CERTIFIED', separator=str(q),
                baseline_moment_lower=str(old_lower), baseline_moment_upper=str(old_upper),
                candidate_moment_lower=str(new_lower), candidate_moment_upper=str(new_upper),
                baseline_rejection_margin=str(old_lower - 66304),
                candidate_acceptance_margin=str(66304 - new_upper), numerical_proposals=numerical,
                proof='For positive ranks below73, M(k)=sum c_r*(r/73)^(1-k) strictly increases. Baseline lower moment>66304>candidate upper moment implies old root<q<new root.',
                scope='Complete-profile complex recurrence root; supplier/native/outer admission is separate.')


def native_and_outer_obligations(local_words_unchanged=True, separator=None):
    b = _base()
    declared = b['data']['new/SPEC.json']['providers']
    reuse = {pid: dict(word_sha256=b['manifest']['files'][relative]['sha256'],
                orientation_program_sha256=deepcopy(declared[pid]['program_hashes']),
                semantic_artifact_sha256=deepcopy(declared[pid]['artifact_semantic_sha256']),
                complete_contract_sha256=semantic_sha(declared[pid]['complete_contract']))
             for pid, relative in WORDS.items()}
    proposal = None
    if separator is not None:
        # This equality is an arithmetic proposal from the held #2802 precision24
        # workflow. Passing it is deliberately not called outer verification.
        q = Q(separator)
        k = q - Q(1, 10 ** 70) - Q(1, 10 ** 46)
        old = Q(b['data']['outer/OUTER-CLAIM.json']['kappa'])
        proposal = dict(complex_lower_proposal=str(q), outer_kappa_proposal=str(k),
                        exceeds_pinned_outer_headline=k > old,
                        formula='C-10^-70-10^-46 (held precision24 workflow)',
                        arithmetic_only=True, full_outer_verification=False)
    return dict(native_supplier=dict(status='UNRUN', unchanged_words=local_words_unchanged,
                    source_bound_reuse_possible=local_words_unchanged,
                    declarations_only=reuse,
                    required=['complete native artifact tree bound to these exact word bytes',
                              'native, ledgers, local-replay, wrappers, phases all pass',
                              'actual paid profiles and ordered widths in both orientations',
                              'independent all-column replay, warp recipes, Clifford phases, residual adapters',
                              'retained-parent receipt with source/claim/native pins']),
                strict_global_supplier=dict(status='UNRUN', required=[
                    'reconstruct changed owners and parent lift',
                    'rebind source/target interfaces, native invoices and physical stock including72 private buffers',
                    'full strict supplier/precision/endpoint discovery with current fill/profile',
                    'new candidate manifest and source-bound release receipt']),
                outer=dict(status='UNRUN', proposal=proposal, required=[
                    'independently evaluate modern fine-prime-padding ledger at new admitted complex endpoint',
                    'all strict gaps, bit-supplier constraints, layout and precision guards',
                    'headline rational kappa exceeds pinned #2853 outer claim',
                    'two independent arithmetic checkers and full release binding']),
                inherited_theorem=dict(status='CONDITIONAL_INHERITED', obligations=[
                    'all-size compiler and machine realization', 'common labels and mutable-source access',
                    'physical hosting and routing', 'precision and fixed-tape contracts',
                    'exact recovery and analytic transfer', 'PR559 recurrence correction',
                    'PR589 bit H1-H5 and cited fine-prime/gauge-free theorems']))


def audit_fill_candidate(spec):
    """Pool worker entry: exact two-seed confirmation of a concrete fill artifact.

    spec = {seed, candidate_path, candidate_sha256, separator?}. The file may
    contain only a changed literal fill; no generated module is imported.
    """
    started = time.process_time()
    b = _base()
    path = Path(spec['candidate_path']).resolve()
    need(path.is_relative_to(RR.resolve()), 'candidate artifact must stay inside styles-r11')
    need(sha(path) == spec['candidate_sha256'], 'candidate artifact digest')
    candidate = read_data(path)
    baseline = b['data']['new/borrow-fill/FILL.json.gz']
    baseline_check = literal_admission(baseline)
    candidate_check = literal_admission(candidate)
    order = list(WORDS)
    random.Random(int(spec['seed'])).shuffle(order)
    local = {pid: local_admission(b['data'][WORDS[pid]], b['manifest']['files'][WORDS[pid]]) for pid in order}
    separation = root_separation(candidate_check['profile'], baseline_check['profile'], spec.get('separator'))
    delta = {rank: candidate_check['profile'].get(rank, 0) - baseline_check['profile'].get(rank, 0)
             for rank in sorted(set(candidate_check['profile']) | set(baseline_check['profile']))
             if candidate_check['profile'].get(rank, 0) != baseline_check['profile'].get(rank, 0)}
    need(_mass(delta) == 0, 'exact complete-profile delta is mass-neutral')
    return dict(status='PASS' if separation['status'] == 'PASS' else 'NULL', seed=int(spec['seed']),
                admission_level='FINITE_COMPLEX_ROOT_IMPROVEMENT' if separation['status'] == 'PASS' else 'NO_CERTIFIED_IMPROVEMENT',
                candidate_artifact=dict(path=str(path.relative_to(RR)), sha256=sha(path)),
                baseline_profile=baseline_check['profile'], candidate_profile=candidate_check['profile'],
                complete_profile_delta=delta, local_audits=local, literal_admission=candidate_check,
                root_separation=separation,
                obligations=native_and_outer_obligations(True, separation['separator']),
                solver_calls=0, n_permutations=0, cpu_seconds=time.process_time()-started,
                scope='Independent finite local algebra, literal hosting and exact complex root separation. No unexecuted native/global/outer stage is promoted to PASS.',
                **provenance())


def admission_controls(seed):
    """Preregistered exact controls; coordinator alone decides when to run."""
    b = _base()
    original = b['data']['new/borrow-fill/FILL.json.gz']
    positive = literal_admission(original)
    labels = ['duplicate_helper', 'out_of_capacity', 'out_of_call_range']
    random.Random(seed).shuffle(labels)
    results = []
    for label in labels:
        rows = list(original['rows'])
        if label == 'duplicate_helper':
            rows[1] = list(rows[0])
        else:
            rows[0] = list(rows[0])
            if label == 'out_of_capacity':
                rows[0][5] = b['model'].win[rows[0][2], rows[0][3]][0]
            else:
                rows[0][0] = b['model'].calls
        bad = dict(original, rows=rows)
        try:
            literal_admission(bad)
        except (ValueError, RuntimeError, AssertionError, KeyError, IndexError) as exc:
            results.append(dict(control=label, rejected=True, reason=str(exc)[:300]))
        else:
            results.append(dict(control=label, rejected=False))
    same = root_separation(positive['profile'], positive['profile'])
    good = all(x['rejected'] for x in results) and same['status'] == 'NOT_CERTIFIED'
    return dict(status='PASS' if good else 'ERROR', seed=seed, baseline=positive,
                negative_controls=results, equal_profile_not_improved=same,
                n_permutations=0, scope='Exact admission controls, not an inferential test family.', **provenance())
